package cz.muni.fi.pb162.hw02.crawler;

/**
 *
 * @author Jakub Cechacek
 */
public interface SmartCrawler extends IndexCrawler, ReverseIndexCrawler {
}
